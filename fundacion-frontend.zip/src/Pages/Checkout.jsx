import React from 'react'

function Checkout() {
  return (
    <div className="content-below-navbar">

      <div>Checkout</div>
    </div>
  )
}

export default Checkout